import styled from 'styled-components';

export const Container = styled.div``;

export const Titulo = styled.h1``;